// const BASE_URL = "https://frontendauth.nextpetapp.com";
const BASE_URL = "https://admin.nextpetapp.com";
export default BASE_URL;

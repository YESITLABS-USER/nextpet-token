import React from 'react';
function RecentlyPosted() {
  return ( 
    <>
        <div className="between-bannershead-wrap pt-5" style={{ width: "100%"}}>
            <img src="/images/Nextpet-imgs/recently-posted-imgs/side1.png" alt="img"  />
              <h1 style={{ }}>Recently Posted</h1>

            <div style={{ position: 'relative',}}>
              <img src="/images/Nextpet-imgs/recently-posted-imgs/side2.png" alt="img" style={{ }} />
            </div>
            
        </div>

    </>
  );
}
export default RecentlyPosted;

// BANNER-CAT-SLIDER

// $(document).ready(function () {
//     $("#banner-cat-slider").owlCarousel({
//         items: 6,
//         loop: false,
//         center: false,
//         autoplay: false,
//         margin: 0,
//         dots: false,
//         nav: true,
//         rewind: true,
//         autoplayTimeout: 3000,
//         autoplaySpeed: 1000,
//         autoplayHoverPause: true,
//         responsive: {
//             0: {
//                 items: 1,
//             },
//             600: {
//                 items: 3,
//             },
//             1000: {
//                 items: 6,
//             }
//         }
//     });
//     $(".owl-prev").html('<i class="far fa-chevron-left"></i>');
//     $(".owl-next").html('<i class="far fa-chevron-right"></i>');
// });

// BANNER-CAT-SLIDER

// NEW YEAR CATS DOG-SLIDER

// $(document).ready(function () {
//     $("#newyear-cat-dog-slider,#popular-breeders-slider").owlCarousel({
//         items: 4,
//         loop: false,
//         center: false,
//         autoplay: false,
//         margin: 30,
//         dots: false,
//         nav: true,
//         rewind: true,
//         autoplayTimeout: 3000,
//         autoplaySpeed: 1000,
//         autoplayHoverPause: true,
//         responsive: {
//             0: {
//                 items: 1,
//             },
//             600: {
//                 items: 3,
//             },
//             1000: {
//                 items: 4,
//             }
//         }
//     });
//     $(".owl-prev").html('<i class="far fa-chevron-left"></i>');
//     $(".owl-next").html('<i class="far fa-chevron-right"></i>');
// });


// NEW YEAR CATS DOG-SLIDER

// RECENTLY POSTED SLIDER

// $(document).ready(function () {
//     $("#recentposted-cat-dog-slider,#trending-pets-slider").owlCarousel({
//         items: 4,
//         loop: false,
//         center: false,
//         autoplay: false,
//         margin: 30,
//         dots: false,
//         nav: true,
//         rewind: true,
//         autoplayTimeout: 3000,
//         autoplaySpeed: 1000,
//         autoplayHoverPause: true,
//         responsive: {
//             0: {
//                 items: 1,
//             },
//             600: {
//                 items: 3,
//             },
//             1000: {
//                 items: 4,
//             }
//         }
//     });
//     $(".owl-prev").html('<i class="far fa-chevron-left"></i>');
//     $(".owl-next").html('<i class="far fa-chevron-right"></i>');
// });



// RECENTLY POSTED SLIDER


// POST CREATE SLIDER

// $(document).ready(function () {
//     $("#uploaded-post-imgs").owlCarousel({
//         items: 1,
//         loop: false,
//         center: false,
//         autoplay: false,
//         margin: 20,
//         dots: true,
//         nav: false,
//         rewind: true,
//         autoplayTimeout: 3000,
//         autoplaySpeed: 1000,
//         autoplayHoverPause: true,
//         responsive: {
//             0: {
//                 items: 1,
//             },
//             600: {
//                 items: 1,
//             },
//             1000: {
//                 items: 1,
//             }
//         }
//     });
//     $(".owl-prev").html('<i class="far fa-chevron-left"></i>');
//     $(".owl-next").html('<i class="far fa-chevron-right"></i>');
// });



// POST CREATE SLIDER





